var express = require('express'),
    bodyParser = require('body-parser'),
    mongoose = require('mongoose'),
    pug = require('pug');

var app = express();

app.use(bodyParser.json());
app.set('view engine', 'pug');

app.get('/', function (req, res) {
    mongoose.connect('mongodb://localhost/ihk');
    var Tweet = mongoose.model('Tweet', {
        text: String,
    });
    Tweet.find({}).select('text').exec(function (err, data) {
        console.log(data);
    });
    res.render('index', {});
});

app.listen(2356, function (err) {
    console.log('Starting up NodeJS server!');
});
